self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9661dca330c38b86a9ffa07655ccaded",
    "url": "/SOOCaml-frontend/index.html"
  },
  {
    "revision": "d946680c26e32f9db6b0",
    "url": "/SOOCaml-frontend/static/css/2.7a7d2dfe.chunk.css"
  },
  {
    "revision": "8d93884de96e08604f28",
    "url": "/SOOCaml-frontend/static/css/main.092e11c7.chunk.css"
  },
  {
    "revision": "d946680c26e32f9db6b0",
    "url": "/SOOCaml-frontend/static/js/2.b2e12971.chunk.js"
  },
  {
    "revision": "e0cc419307a21d9d8b13d09980919fa8",
    "url": "/SOOCaml-frontend/static/js/2.b2e12971.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8d93884de96e08604f28",
    "url": "/SOOCaml-frontend/static/js/main.6c18e9ca.chunk.js"
  },
  {
    "revision": "965e87059617d4ac0d05",
    "url": "/SOOCaml-frontend/static/js/runtime-main.f8271a27.js"
  }
]);